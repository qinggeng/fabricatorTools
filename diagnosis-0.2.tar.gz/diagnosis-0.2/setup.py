#-*- coding: utf-8 -*-
from setuptools import setup
setup(  name = 'diagnosis',
     version = '0.2',
 description = u'diagnosis (or debug) tools',
         url = 'https://github.com/qinggeng/diagnosis',
      author = 'huangyangkun',
author_email = 'huangyangkun@outlook.com',
     license = 'MIT',
    packages = ['diagnosis'],
    zip_safe = False)

