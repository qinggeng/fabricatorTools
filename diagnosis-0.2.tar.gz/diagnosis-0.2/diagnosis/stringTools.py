#-*- coding: utf-8 -*-
def linkArray(arr, sep = ', ', t=str):
        return reduce(lambda x, y: x + t(y) + sep, arr, '')[:-(len(sep))]

if __name__ == '__main__':
    print linkArray(list(range(10)))
