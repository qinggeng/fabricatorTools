#-*- coding: utf-8 -*-
import os

from traceback import format_exc as fme
from inspect import currentframe, getframeinfo

runcmd = os.system

def filterAttr(iterable, attrName):
    return map(lambda x: getattr(x, attrName), iterable)

def listAttr(obj, filterStr=''):
    """filtering attr names of objects"""
    return filter(lambda x: x.startswith(filterStr) == True, dir(obj))

def pause():
	print('press any key to continue...')
	os.system('read')

def currLine():
    cf = currentframe()
    frameinfo = getframeinfo(cf.f_back)

    return u'[{f}: {l}]'.format(f = frameinfo.filename, l = frameinfo.lineno)

if __name__ == '__main__':
    print listAttr("", "__")

