#-*- coding: utf-8 -*-
import os
def optionalJsonVal(path, jsonObject, defaultVal = None):
	try:
		keys = path.split('.')
		for key in keys[:-1]:
			if key.isdigit():
				jsonObject = jsonObject[int(key)]
			else:
				jsonObject = jsonObject[key]
		if keys[-1].isdigit():
			ret = jsonObject[int(keys[-1])]
		else:
			ret = jsonObject[keys[-1]]
		if type(ret) == str:
			return unicode(ret.decode('utf-8'))
		return ret
	except Exception, ex:
		return defaultVal
